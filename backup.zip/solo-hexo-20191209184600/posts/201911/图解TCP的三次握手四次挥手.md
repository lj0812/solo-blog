title: 图解TCP的三次握手四次挥手
date: '2019-11-27 15:05:56'
updated: '2019-12-02 15:57:12'
tags: [TCP]
permalink: /articles/2019/11/27/1574838356041.html
---
![TCP.jpg](https://img.hacpai.com/file/2019/11/TCP-9ebe65d2.jpg)

## 三次握手

1. 客户端主动提出握手：`SYN=1 seq=x`；之后客户端进入 **SYN_SENT** 状态
2. 服务器处于 **LISTEN** 状态，接收后表示好感，回应：`SYN=1 ACK=1 ack=x+1 seq=y`；之后进入 **SYN_RCVD** 状态
3. 客户端收到回应后再次确认：`ACK=1 ack=y+1 seq=x+1`；之后进入 **ESTABLISED** 状态
4. 服务器接收到后从 **SYN_RCVD** 状态进入 **ESTABLISED** 状态

## 四次挥手

1. 客户端主动提出分别：`FIN=1 seq=u`；之后进入 **FIN_WAIT_1** 状态
2. 服务端得知要分别，回应：`ACK=1 ack=u+1 seq=v`；进入 **CLOSE_WATI** 状态，准备挥手
3. 客户端收到回应后，无言，默默进入 **FIN_WAIT_2** 状态
4. 服务端发起挥手：`FIN=1 ACK=1 ack=u+1 seq=w`；进入 **LAST_ACK** 状态
5. 客户端挥手分别：`ACK=1 ack=w+1 seq=u+1`；进入 **TIME_WAIT** 状态，2s后进入 **CLOSED** 状态
6. 服务端接到确认分别后，进入 **CLOSED** 状态
