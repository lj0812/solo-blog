title: SSH免密登录
date: '2019-07-30 15:54:53'
updated: '2019-07-30 15:54:53'
tags: [SSH]
permalink: /articles/2019/07/30/1564473293597.html
---
# SSH免密登录

  

[TOC]

  

## 第一步：生成秘钥对

  

参考[ssh-keygen](https://blog.hereis.me/articles/2019/07/30/1564472947025.html#%E7%BB%86%E5%88%99)

  

## 第二步：将公钥上传到目标服务器

  

> 公钥生效需满足至少下面两个条件：

> 1 .ssh目录的权限必须是700

> 2 .ssh/authorized_keys文件权限必须是600

  

- ssh-copy-id 方式（推荐）

  

``` shell

ssh-copy-id -i ~/.ssh/<公钥>  <user>@<romte_ip>

```

  

- scp方式

  

``` shell

scp -p ~/.ssh/<公钥>  <user>@<remote_ip>:/root/.ssh/authorized_keys

```

  

或者

  

``` shell

scp ~/.ssh/<公钥> root@<remote_ip>:<path>/<公钥>

cat <path>/<公钥>  >>~/.ssh/authorized_keys // 需登录服务器

```

  

## 第三步：简化登录（可选）

  

- 添加一个别名

  

``` shell

alias hi='ssh <user>@<remote_ip>'

// 之后命令行

  

> hi

  

// 默认是id_rsa，如果上传的key是自己额外又生成的需要额外指定使用哪个

alias hi='ssh -i path/to/对应私钥 <user>@<reomot_ip>'

  

```

  

- 配置SSH config

  

``` shell

// ~/.ssh/config 新增一条记录

  

Host me

HostName <remote_ip>

Port 22

User root

IdentityFile ~/.ssh/<公钥>

  

// 之后命令行

  

> ssh me

  

```

  

---

  

*Centos`7`更改ssh登录端口*

  

1. 修改 `/etc/ssh/sshd_config`文件中`Port`到指定端口

2. 重启ssh：`systemctl restart sshd`