title: Semantic Versioning（语义版本控制）
date: '2019-07-30 15:38:16'
updated: '2019-07-30 15:38:16'
tags: [待分类]
permalink: /articles/2019/07/30/1564472296226.html
---
# Semantic Versioning（语义版本控制）



[TOC]



## 先看看几种写法

``` json

{

  "dependencies": {

    "package-1": ">=2.0.0 <3.1.4",

    "package-2": "^0.4.2",

    "package-3": "~2.7.1"

    "package-4": "2.3.x"

  }

}

```



## Comparators


|comparator|description|
| -------: |----|
| `<2.0.0` | Any version that is less than 2.0.0|
| `<=3.1.4` | Any version that is less than or equal to 3.1.4|
| `>0.4.2` | Any version that is greater than 0.4.2|
| `>=2.7.1` | Any version that is greater than or equal to 2.7.1|
| `=4.6.6` | Any version that is equal to 4.6.6|
| `>=2.0.0 <3.1.4` | Greater than or equal to 2.0.0 and less than 3.1.4|
| `<2.0.0 \|\| >3.1.4` | Less than 2.0.0 or greater than 3.1.4|



## Hyphen Ranges

|Version range|Expanded version range|
|---|---|
|`2.0.0 - 3.1.4`|`>=2.0.0 <=3.1.4`|
|`0.4 - 2`|`>=0.4.0 <=2.0.0`|



## X-Ranges

Any of `X`, `x`, or `*` can be used to leave part or all of a version unspecified.

|Version range|Expanded version range|
|---|---|
|`*`|`>=0.0.0`|
|`2.x`|`>=2.0.0 <3.0.0`|
|`3.1.x`|`>=3.1.0 <3.2.0`|



## Tilde Ranges

Using `~` with a minor version specified allows patch changes. Using `~` with only major version specified will allow minor changes.

|Version range|Expanded version range|
|---|---|
|`~3.1.4`|`>=3.1.4 <3.2.0`|
|`~3.1`|`3.1.x`or`>=3.1.0 <3.2.0`|
|`~3`|`3.x`or`>=3.0.0 <4.0.0`|

> **Note:** Specifying pre-releases in tilde ranges will only match pre-releases in that same full version. For example, the version range ~3.1.4-beta.2 would match against 3.1.4-beta.4 but not 3.1.5-beta.2 because the major.minor.patch version is different.



## Caret Ranges

Allow changes that do not modify the **first non-zero digit** in the version, either the 3 in 3.1.4 or the 4 in 0.4.2.

|Version range|Expanded version range|
|---|---|
|`^3.1.4`|`>=3.1.4 <4.0.0`|
|`^0.4.2`|`>=0.4.2 <0.5.0`|
|`^0.0.2`|`>=0.0.2 <0.0.3`|



[learn more](https://github.com/npm/node-semver)