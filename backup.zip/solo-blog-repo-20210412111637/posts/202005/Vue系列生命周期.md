title: Vue系列-生命周期
date: '2020-05-11 22:47:56'
updated: '2020-05-11 22:47:56'
tags: [Vue, 前端]
permalink: /articles/2020/05/11/1589208476284.html
---
Vue 实例有一个完整的生命周期，也就是从开始创建、初始化数据、编译模版、挂载 Dom -> 渲染、更新 -> 渲染、卸载等一系列过程，我们称这是 Vue 的生命周期。

![523F2C15E6C77B765FADC019AA1FBA6E.jpg](https://img.hacpai.com/file/2020/05/523F2C15E6C77B765FADC019AA1FBA6E-b5a79640.jpg)

> 所有的生命周期钩子自动绑定 this 上下文到实例中，因此你可以访问数据，对 property 和方法进行运算。这意味着你不能使用箭头函数来定义一个生命周期方法

## 基础生命周期

1. **beforeCreate**
   * 在实例初始化之后，数据观测 (data observer) 和 event/watcher 事件配置之前被调用。
2. **created**
   * 在实例创建完成后被立即调用。
   * 在这一步，实例已完成以下的配置：数据观测 (data observer)，property 和方法的运算，watch/event 事件回调。
   * 然而，挂载阶段还没开始，$el property 目前尚不可用。
3. **beforeMount**
   * 在挂载开始之前被调用：相关的 render 函数首次被调用。
   * 该钩子在服务器端渲染期间不被调用。
4. **mounted**
   * 实例被挂载后调用，这时 el 被新创建的 vm.\$el 替换了。如果根实例挂载到了一个文档内的元素上，当 mounted 被调用时 vm.$el 也在文档内。
   * 注意 mounted 不会保证所有的子组件也都一起被挂载。如果你希望等到整个视图都渲染完毕，可以在 mounted 内部使用 vm.$nextTick
   * 该钩子在服务器端渲染期间不被调用。
5. **beforeUpdate**
   * 数据更新时调用，发生在虚拟 DOM 打补丁之前。
   * 这里适合在更新之前访问现有的 DOM，比如手动移除已添加的事件监听器。
   * 该钩子在服务器端渲染期间不被调用，因为只有初次渲染会在服务端进行。
6. **updated**
   * 由于数据更改导致的虚拟 DOM 重新渲染和打补丁，在这之后会调用该钩子
   * 当这个钩子被调用时，组件 DOM 已经更新，所以你现在可以执行依赖于 DOM 的操作
   * 应该避免在此期间更改状态。如果要相应状态改变，通常最好使用计算属性或 watcher 取而代之
   * 注意 updated 不会保证所有的子组件也都一起被重绘。如果你希望等到整个视图都重绘完毕，可以在 updated 里使用 vm.$nextTick
   * 该钩子在服务器端渲染期间不被调用。
7. **beforeDestroy**
   * 实例销毁之前调用。在这一步，实例仍然完全可用。
   * 该钩子在服务器端渲染期间不被调用。
8. **destroyed**
   * 实例销毁后调用
   * 该钩子被调用后，对应 Vue 实例的所有指令都被解绑，所有的事件监听器被移除，所有的子实例也都被销
   * 该钩子在服务器端渲染期间不被调用。

## keep-alive 独有的生命周期

1. **activated**
   * 被 keep-alive 缓存的组件激活时调用
   * 该钩子在服务器端渲染期间不被调用。
2. **deactivated**
   * 被 keep-alive 缓存的组件停用时调用。
   * 该钩子在服务器端渲染期间不被调用。

## 子孙组件生命周期相关

* errorCaptured
  * 当捕获一个来自子孙组件的错误时被调用
  * (err: Error, vm: Component, info: string) => ?boolean
    * 此钩子会收到三个参数：错误对象、发生错误的组件实例以及一个包含错误来源信息的字符串。此钩子可以返回 false 以阻止该错误继续向上传播。
  * 错误传播规则
    * 默认情况下，如果全局的 config.errorHandler 被定义，所有的错误仍会发送它，因此这些错误仍然会向单一的分析服务的地方进行汇报。
    * 如果一个组件的继承或父级从属链路中存在多个 errorCaptured 钩子，则它们将会被相同的错误逐个唤起。
    * 如果此 errorCaptured 钩子自身抛出了一个错误，则这个新错误和原本被捕获的错误都会发送给全局的config.errorHandler。
    * 一个 errorCaptured 钩子能够返回 false 以阻止错误继续向上传播。本质上是说“这个错误已经被搞定了且应该被忽略”。它会阻止其它任何会被这个错误唤起的 errorCaptured 钩子和全局的 config.errorHandler。
* 加载渲染过程

父 beforeCreate -> 父 created -> 父 beforeMount -> 子 beforeCreate -> 子 created -> 子 beforeMount -> 子 mounted -> 父 mounted

* 父组件更新过程

父 beforeUpdate -> 父 updated

* 父组件引起子组件更新过程

父 beforeUpdate -> 子 beforeUpdate -> 子 updated -> 父 updated

* 销毁过程

父 beforeDestroy -> 子 beforeDestroy -> 子 destroyed -> 父 destroyed