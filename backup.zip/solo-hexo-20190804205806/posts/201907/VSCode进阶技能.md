title: VS Code 进阶技能
date: '2019-07-30 16:04:31'
updated: '2019-07-30 16:04:31'
tags: [工具, VSCode]
permalink: /articles/2019/07/30/1564473871197.html
---
# VS Code进阶技能

[TOC]

## 滚动到文件中某个特定的行和列

``` shell
code -g <file:line[:character]>
```

## 比较两个文件的内容

``` shell
code -d a.txt b.txt
```

## 光标移动一个单词

``` shell
option + 方向键
```

## 光标移动到行首或行尾

``` shell
cmd + 方向键
```

## 代码块的光标移动

``` shell
cmd + shift + \
```

## 光标移动到文档的第一行或者最后一行

``` shell
cmd + 上下键
```

## 文本选择

在以上光标移动的基础上按住shift（代码块除外）

## 删除选中的整行

``` shell
cmd + shift + k
```

## 剪切光标所在行

``` shell
cmd + x
```

## 在光标所在行 下面 开始

``` shell
cmd + enter
```

## 在光标所在行 上面 开始

``` shell
cmd + shift + enter
```

## 移动代码

``` shell
option + 上下方向键
```

## 复制光标所在行到 上/下面

``` shell
option + shift + 上下方向键
```

## 注释一行代码

``` shell
cmd + /
```

## 注释整段代码

``` shell
option + shift + a
```

## 调整光标前后的字符位置

``` shell
Ctrl + t
```

## 合并代码行

``` shell
Ctrl + j
```

## 撤销光标的移动和选择

``` shell
cmd + u
```

## 创建多光标

``` shell
1. 使用鼠标
按住option 点击左键
2. 使用键盘
cmd + option + 上下方向键
3. 特别命令
cmd + d （cmd + k跳过）（选中相同单词）
option + shift + i（在选中行的行尾添加）
```

## 文件跳转

``` shell
ctrl + tab（文件较少时）
或者
cmd + p （最近打开的文件列表） -> 找到文件后 -> enter（当前窗口打开） / cmd + enter（新窗口打开）
```

## 行跳转

``` shell
Ctrl + g  -> 输入行号（当前文件）
或者
cmd + p 输入文件名，然后加上 : 指定行号（快捷跳转到其他文件的指定行）
```

## 符号跳转

``` shell
cmd + shift + o （加上 : 后对符号进行分类）（当前文件）
或者
cmd + t （文件里搜索符号，仅js）（在多个文件里进行符号跳转）
```

## 跳转到函数实现

``` shell
cmd + f12
```

## 引用跳转

``` shell
shift + f12
```
