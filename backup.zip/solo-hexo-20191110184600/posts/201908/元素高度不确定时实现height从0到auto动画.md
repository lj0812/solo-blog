title: 元素高度不确定时实现height从0到auto动画
date: '2019-08-01 18:44:47'
updated: '2019-08-01 18:44:47'
tags: [前端, CSS, 奇技]
permalink: /articles/2019/08/01/1564656287489.html
---
## 原理
* CSS `transition`只适用于明确的值，auto这种无法实现过度
* CSS `var()`函数可以代替元素中任何属性中的值的任何部分

## 答案

HTML部分
```html
<div class="trigger">
  Hover me to see a height transition.
  <div class="el">content</div>
</div>
```

CSS部分
``` css
.el {
  transition: max-height 0.5s;
  overflow: hidden;
  max-height: 0;
}

.trigger:hover > .el {
  max-height: var(--max-height);
}
```
JavaScript部分
``` JavaScript
var el = document.querySelector('.el')
var height = el.scrollHeight
el.style.setProperty('--max-height', height + 'px')
```