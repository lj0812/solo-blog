title: Daily Log
date: '2019-09-17 16:40:49'
updated: '2019-09-17 16:43:15'
tags: [待分类]
permalink: /articles/2019/09/17/1568709649894.html
---
# Daily Log

## 2019-07-31

### 弹窗可以通过 open(url, name, params) 调用。它返回新窗口的引用

* name相同将替换窗口链接，这可以实现webpack总是打开一个窗口调试，同时可以通过返回的窗口引用关闭窗口。



## 2019-07-16

### mouseover/out和mouseenter/leave的区别和共同点

* 共同点：mouseover/out、mouseenter/leave事件有一个额外的目标：relatedTarget，作为起点/终点的元素，是对target的补充

* 不同点：

    * mouseover/out即使从父元素转到子元素时也会被触发，假设鼠标一次只会移入一个元素，能冒泡

    * mouseenter/leave鼠标进入子元素也不会被触发，只关注鼠标在整个元素的内部还是外部，不会冒泡



### 性能优化

* 长图文中，可将真实图片放入data-src中，src使用加载图，然后监听滚动事件，检查图片元素是否出现在可视范围内(elem.getBoundingClientRect())，出现则用data-src替换src



### async和defer属性的异同

* 相同点

    * 不会阻塞页面的渲染

* 不同点

    * async 加载优先，先加载完先执行，与DOMContentLoaded无关

    * defer 文档顺序，排在前面先执行，在DOMContentLoaded之前在文档加载解析之后执行



### 如何防止滚动

* 阻止whell事件

* 阻止pageUp、pageDown的keydown事件

* 不能在onscroll监听者中通过event.preventDefault()来阻止滚动，因为它在滚动事件发生之后才出发



## 2019-07-15

### 单击事件which属性

* event.which == 1 —— 左按钮

* event.which == 2 —— 中间按钮

* event.which == 3 —— 右按钮



### 在Mac上通常使用cmd而不是Ctrl

* 在Mac上左击+Ctrl会被解释为右击，会生成contextmenu事件

* 如果想让所有系统用户感到舒适，应该和CtrlKey一起使用metaKey，对于js意味着应该检查`if (event.ctrlKey || event.metaKey)`



### 如何阻止双击选择文本

* 文本选择是mousedown事件的默认浏览器操作，比较好的解决方案是处理mousedown并阻止他发生

* 使用 getSelection().removeAllRanges() 取消选择后的内容

* CSS 属性 user-select:none（带有浏览器前缀）完全禁用文本选择



## 2019-07-12

### 各个尺寸代表的含义

![image.png](https://img.hacpai.com/file/2019/09/image-0c753b16.png)


* offsetParent：最近的祖先元素
    * CSS定位（position为absolute、relative或fixed）
    * `<td>`、`<th>`、`<table>`
    * `<body>`
* offsetLeft/offsetTop：当前元素左上角相对于 offsetParent 节点的左/上边界偏移的像素值
* offsetWidth/offsetHeight：元素的“外部”宽度/高度，它的完整大小包括边框、内边距、内容、滚动条（如果存在的话）
* clientLeft/clientTop：内测和外侧的相对坐标，约等于边框，但当出现滚动条在左侧时，包含滚动条的宽度
* clientWidth/clientHeight：元素边框内区域的大小，包括内边距、内容，不包括滚动条
* scrollLeft/scrollTop：元素隐藏、滚动部分的宽度/高度，相对于client，可修改，*将 scrollTop 设置为 0 或 Infinity 将使元素分别滚动到顶部/底部*
* scrollWidth/scrollHeight：内容的实际宽高

### getComputedStyle(elem).width 与 elem.clientWidth 的区别
* clientWidth的值是数值，getComputedStyle(elem).width返回一个包含px的字符串
* getComputedStyle(elem)可能返回非数值的结果，比如auto
* clientWidth是元素的内容区域加上内间距，而CSS宽度（具有标准的box-sizing）是内部不包括内间距的空间区域
* clientWidth总是不包括滚动条的宽度

### window相关尺寸和滚动
* 获取窗口的宽高使用document.documentElement.clientWidth/Height，不使用window.innerWidth/Height，因为后者包含滚动条
* 文档的宽度高度使用Math.max(document.body.scrollHeight, document.documentElement.scrollHeight, document.body.offsetHeight, document.documentElement.offsetHeight, document.body.clientHeight, document.documentElement.clientHeight) 
* 文档的滚动位置，由于bug([157855](https://bugs.chromium.org/p/chromium/issues/detail?id=157855)，[106133](https://bugs.webkit.org/show_bug.cgi?id=106133)),部分情况下需使用document.body代替document.documentElement来获取scrollLeft/Top属性，同时可以使用window.pageXOffset/pageYOffset代替
* 滚动页面可以通过修改document.documentElement.scrollTop/Left的值来实现，但由于上面bug的原因，部分需要修改document.body.scrollTop/Left,更好的解决方案是window.scrollBy(x, y)和window.scrollTo(pageX, pageY)
* 使用element.scrollIntoView(top)使元素出现在窗口顶部(top=true)或底部(top=false)
* 使用document.body.style.overflow = "hidden"禁止文档滚动，使用document.body.style.overflow = "" 恢复滚动，滚动条的消失带来的页面变化的情况可以通过对比前后clientWidth,将对应的padding值添加到document.body中取代滚动条以保持页面内容宽度

### 事件奇技
* 尽量避免使用阻止冒泡，使用其他方法替代
* 如果默认动作被阻止，event.defaultPrevented的值会变成true,可以利用这个特性从上次判断这个属性来模拟组织冒泡

## 2019-07-11

* 将 scrollTop 设置为 0 或 Infinity 将使元素分别滚动到顶部/底部



## 2019-07-10



### DOM属性和HTML特性

* DOM属性

    * DOM上的属性和方法就像标准的JavaScript对象

    * 值并不只是字符串

* HTML特性

    * 浏览器读取HTML文本并根据标签生成DOM对象，它会辨别标准化特性然后以此创建DOM属性

    * 不区分大小写

    * 值只能是字符串

    * 相关方法

        * removeAttribute()：删除属性

        * setAttribute()：写入某个属性值

        * getAttribute()：读取某个属性的值

        * getAttributeNames()：返回当前元素的所有属性名

        * hasAttribute()：某个属性是否存在

        * hasAttributes()：当前元素是否有属性

    * elem.attributes：获取所有特性，是个NamedNodeMap类型的值

* 属性-特性的同步

    * 当一个标准化的特性被改变，相应的属性随之改变，反之亦然

    * input.value只能从特性同步到属性，反之不行，即通过setAttribute('value', 'value')可以改变input.value的值，反过来不行



### 操作DOM

* 创建节点的方法：

    * document.createElement(tag) —— 用给定标签创建一个节点，

    * document.createTextNode(value) —— 创建一个文本节点（很少使用），

    * elem.cloneNode(deep) —— 如果参数 deep==true 将元素及后代子元素进行克隆。

* 插入和移除节点的方法：（这些方法都返回 node）

    * 从 parent

        * parent.appendChild(node)

        * parent.insertBefore(node, nextSibling)

        * parent.removeChild(node)

        * parent.replaceChild(newElem, node)

    * 添加一些节点和字符串：

        * node.append(...nodes or strings) —— 在 node 末尾位置增加，

        * node.prepend(...nodes or strings) —— 在 node开头位置增加 ，

        * node.before(...nodes or strings) —— 在 node 之前位置增加，

        * node.after(...nodes or strings) —— 在 node 之后位置增加，

        * node.replaceWith(...nodes or strings) —— 替换 node。

        * node.remove() —— 移除 node。

    * 在 HTML 中添加内容 elem.insertAdjacentHTML(where, html)，在 where 位置进行操作：

        * "beforebegin" —— 将 html 插入 elem 到开头的前面位置，

        * "afterbegin" —— 将 html 插入 elem 到开头的后面位置，

        * "beforeend" —— 将 html 插入 elem 到结尾的前面位置，

        * "afterend" —— 将 html 插入 elem 到结尾的后面位置。



> 所有插入操作都会从节点原来的位置把节点移除，所以如果想要移动一个元素到另一个地方，不需要移除旧的元素

> elem.insertAdjacentText 和 elem.insertAdjacentElement 跟 elem.insertAdjacentHTML 很相似，只不过他们一个用来插入字符串，一个用来插入元素，但是很少使用这两个方法。



### 样式和类

* class

    * className

    * classList

        * .add

        * .remove

        * .toggle

        * .contains

* style

    * 对于多单词，使用 camelCase，即-x变成X(z-index -> zIndex, -moz-border-radius -> MozBorderRadius)    

    * 将某个样式置为空字符串，浏览器一般会应用CSS类以及内置样式，就像根本没有这样的style属性

    * 用style.cssText进行重写样式，效果类似于 setAttribute('style', '...')

    * 样式值中必须附上CSS单位

    * style属性仅对style属性值进行操作，而不是任何CSS级联，因此不能使用element.style来读取来自CSS类的任何内容

* getComputedStyle

    * 返回的是属性的解析值

    * 需要完整的属性名，像padding这种值会存在浏览器差异，正确的方式是获取paddingTop等值



## 2019-07-09

### 关于innerHTML

* 功能拆解

    * 移除旧的内容

    * 新的innerHTML被书写（旧的和新的相连接）

* 特点

    * 因为内容“零输出”并且被从头重写，所有的图片和其他资源都会被重新加载



### 关于outerHTML

* outerHTML属性包含元素的完整HTML，就像是innerHTML加上元素本身

* 写入到outerHTML后不会改变元素，而是作为一个整体替代了它

* 旧的内容仍可通过element.outerHTML取到，新的内容需通过查询DOM来获取引用



## 2019-07-08

* 空格和换行符是完全有效的字符，它们形成文本节点并成为DOM的一部分，但有2个顶级排除项目

    * 由于历史原因，`<head>`之前的空格和换行符被忽略

    * 如果在`</body>`之后放置了一些东西，它会自动移到body内部，因为HTML规范要求所有内容必须位于body内，所以</body>后面没有空格



### DOM 集合的特点

* 只读的

* 实时的



### parentElement和parentNode的区别

大部分情况下没有区别，只有document.documentElement.parentNode === document，而document.documentElement.parnetElement === null，原因是document不是元素节点



### DOM节点搜索总结

|Method|Searches by...|Can call on an element|Live?|
|------|--------------|----------------------|-----|
|getElementById|id|-|-|
|getElementsByName|name|-|✔|
|getElementsByTagName|tag or '*'|✔|✔|
|getElementsByClassName|class|✔|✔|
|querySelector|CSS-selector|✔|-|
|querySelectorAll|CSS-selector|✔|-|


## 2019-07-05

### 模块相比普通脚本的区别

* 始终使用"use strict"

* 模块级作用域，即每个模块都有自己的顶级作用域

* 模块代码仅在第一次导入时解析

* import.meta对象包含当前模块的一些信息

* 顶级"this"是undefined



### 特定于浏览器的功能

* 模块脚本是延迟解析的，就和defer属性一样

    * 不会阻塞HTML的解析，与其他资源并行加载

    * 直到HTML文档完全解析渲染后模块脚本才开始执行

    * 执行脚本的相对顺序：前面的先执行

* 内联脚本是异步的，内联脚本和外部脚本都允许使用<script async type="module">属性，当导入的模块被处理时，异步脚本会立即执行，与其他的脚本或者HTML文档无关

* 外部脚本相较于其他脚本的差异

    * 具有相同src属性值的外部脚本仅运行一次

    * 从其他域名获取的外部脚本需要加上CORS头

* 不允许裸模块：在浏览器中，必须给与import一个相对或者绝对的URL，没有给定路径的模块称为“裸”模块，import中不允许使用这些模块

* 兼容性：“nomodule”



### 导出export类型

* 声明之前

    * export [default] class/function/variable

* 单个导出

    * export { x [as y], ...}

* 重新导出

    * export { x [as y], ...} from "module"

    * export * from "module" (不会重新导出default)

    * export { default [as y]} from "module"



### 导入import类型有以下几种

> import命令具有提升效果，会提升到整个模块的头部，首先执行



* 模块中的命名导出

    * import { x [as y], ...} from "module"
* 默认导出

    * import x from "module"

    * import { default as x } from "module"

* 导入全部导出

    * import * as obj from "module"



### 模块体系

* CommonJS

    * 就近原则

* AMD (RequireJS)

    * 依赖前置

    * 提前执行（2.0可延迟）

* CMD (Sea.js)

    * 依赖就近

    * 延迟执行



## 2019-07-04

### [可替换元素](https://developer.mozilla.org/zh-CN/docs/Web/CSS/Replaced_element)



* 可替换元素的展现效果不是由CSS来控制的，这些元素是一种外部对象，他们的渲染是独立于CSS的，CSS可以影响替换元素的位置，但不会影响到可替换元素自身的

* 典型的可替换元素

    * `<iframe>`

    * `<video>`

    * `<embed>`

    * `<img>`

* 有些元素仅在特定的情况下被作为可替换元素处理

    * `<option>`

    * `<audio>`

    * `<canvas>`

    * `<object>`

    * `<applet>`

* 控制内容框中对象位置

    * object-fit - 指定可替换元素的内容对象在元素盒区域中的填充方式

    * object-position - 指定可替换元素的内容对象在元素盒区域中的位置

* [关于宽高](http://caibaojian.com/inline-vs-block.html)



## 2019-07-02

* promise对象有内部属性

    * state - 最初是“pending”,然后被改为“fulfilled”或“rejected”

    * result - 一个任意值，最初是undefined

* Promise 静态

    * Promise.resolve(value)

        * 根据给定的value值返回resolved promise

    * Promise.reject(error)

        * 根据给定的value值返回rejected promise

    * Promise.all(iterable)

        * 并行运行多个 promise，并等待所有 promise 准备就绪

        * 如果任意给定的 promise 为 reject，那么它就会变成 Promise.all 的错误结果，所以所有的其他结果都会被忽略

    * Promise.race(iterable)

        * 只等待第一个完成，然后继续执行

* 函数前的async关键字有两个作用

    * 总是返回promise

    * 允许在其中使用await

* Promise 处理始终是异步的，因为所有 promise 操作都被放入内部的 “promise jobs” 队列执行，也被称为 “microtask 队列”。因此，.then/catch/finally 处理程序总是在当前代码完成后才被调用。如果我们需要确保一段代码在 .then/catch/finally 之后被执行，最好将它添加到 .then 的链式调用中。

* 还有一个 “macrotask 队列”，用于保存各种事件，网络操作结果，setTimeout —— 调度的方法，等等。这些也被称为 “macrotasks（宏任务）”。引擎使用 macrotask 队列按出现顺序处理它们，Macrotasks 在当前代码执行完成并且 microtask 队列为空时执行


## 2019-06-24

* CSS规范中，作为替换元素，默认的尺寸是300*150



## 2019-06-20

* 设计继承链的方法

    1. Rabbit.prototype = Object.create(Animal.prototype); **推荐**（要重置constructor）

    2. Rabbit.prototype.__proto__ = Animal.prototype;

* 类语法不仅允许在 extends 后指定一个类，也允许指定任何表达式。

* 关键字`super`，指向当前对象的原型对象

* 在JavaScript中，“派生类的构造函数”与所有其他的构造函数之间存在区别，在派生类中，相应的构造函数会被标记为特殊的内部属性`[[ConstructorKind]]: "derived"`。不同点在于

    * 当一个普通构造函数执行时，它会创建一个空对象作为this并继续执行。

    * 派生的构造函数执行时，它并不会做这件事。它期望父类的构造函数来完成这项工作 

* 派生类的构造函数必须调用super，否则this指向的对象不会被创建



## 2019-06-19

* 使用`Object.defineProperty`定义对象属性时，如果属性存在则更新其标志，否则会创建具有给定值和标志的属性，如果没有提供标志，会假定它是false

    ```

    let user = {};

    Object.defineProperty(user, "name", {

        value: "John"

    });

    let descriptor = Object.getOwnPropertyDescriptor(user, 'name'); // { "value": "John", "writable": false, "enumerable": false, "configurable": false }

    ```

* JavaScript 中，所有的对象都有一个隐藏的 [[Prototype]] 属性，它可以是另一个对象或者 null。[[Prototype]] 引用的对象称为“原型”。

* 如果我们想要读取 obj 属性或者调用一个方法，而且它不存在，那么 JavaScript 就会尝试在原型中查找它。写/删除直接在对象上进行操作，它们不使用原型（除非属性实际上是一个 setter）。

* F.prototype 属性与 [[Prototype]] 不同。F.prototype 唯一的作用是：当 new F() 被调用时，它设置新对象的 [[Prototype]]

* F.prototype 的值应该是一个对象或 null：其他值将不起作用。

* "prototype" 属性在设置为构造函数时仅具有这种特殊效果，并且用 new 调用。

* 默认情况下，所有函数都有 F.prototype = {constructor：F}，所以我们可以通过访问它的 "constructor" 属性来获得对象的构造函数

* 基本数据类型同样在包装对象的原型上存储方法：Number.prototype、String.prototype 和 Boolean.prototype。只有 undefined 和 null 没有包装对象。



## 2019-06-17

* 箭头函数不能用作构造函数，他们不能用new调用

* 箭头函数和函数.bind(this)调用的区别

    * .bind(this)创建该函数的“绑定版本”

    * 箭头函数不会创建任何绑定，该函数没有this，在外部上下文中，this的查找与普通变量搜索完全相同



## 2019-06-14

* 全局对象的有效用法

    * 测试全局对象以验证是否支持现代语言特性

    * 创建 “polyfills”：添加环境不支持（比如旧的浏览器）但存在于现代标准中的功能



## 2019-06-13

* 若 ... 出现在函数的参数列表，那它表示的就是 Rest 参数，它会把函数多余的实参收集到一个数组中。

* Rest 参数必须放到参数列表的末尾

* 箭头函数是没有 "arguments" 的