title: JavaScript语言原理
date: '2019-07-30 15:36:16'
updated: '2019-07-30 15:36:16'
tags: [前端, JavaScript]
permalink: /articles/2019/07/30/1564472176508.html
---
# JavaScript语言原理

  

[TOC]

  

## 自动插入分号规则

   

1. 有换行符，且下一个符号是不符合语法的，就尝试插入分号

2. 有换行符，且语法中规定此处不能有换行符，就自动插入分号

3. 源代码结束处，不能形成完整的脚本或者模块结构，就自动插入分号

  

###  `no LineTermiator here`规则：表示它所在的结构中的这一位置不能插入换行符，和规则2强相关

* 带标签的continue语句，不能在continue后插入换行  

* 带标签的break语句，不能在break后插入换行

* return后不能插入换行

* 后自增、后自减运算符前不能插入换行

* 凡是async关键字，后面都不能插入换行

* 箭头函数的剪头前，不能插入换行

* yield之后，不能插入换行

* throw和Exception之间不能插入换行  

  

### 以下情况要注意添加分号

* 以括号开头，即token为`(`

* 以数组开头，即token为`[`

* 以正则表达式开头，即token为`/`

* 以Template开头的语句，即token为`